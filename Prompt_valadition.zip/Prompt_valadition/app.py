import os
from flask import Flask, request, render_template, redirect
from openai import AzureOpenAI

app = Flask(__name__)

# Azure OpenAI settings
azure_oai_endpoint = "https://azureprompt1494.openai.azure.com/"
azure_oai_key = "0cd03522b0ef4df8a9371be40b4d5659"
azure_oai_model = "Demo"

# Initialize the Azure OpenAI client
client = AzureOpenAI(
    azure_endpoint=azure_oai_endpoint, 
    api_key=azure_oai_key,  
    api_version="2023-09-01-preview"
)

def gptOpenAI(text, system_prompt): 
    try: 
        response = client.chat.completions.create(
            model=azure_oai_model,
            temperature=0.7,
            max_tokens=520,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as ex:
        print(ex)
        return None

def prompt_validator(user_prompt, domain):
    # Check if the prompt is relevant to the selected domain
    relevance_check_prompt = f"Is the following prompt related to the domain of {domain}? Answer with 'Yes' or 'No':"
    relevance_check = gptOpenAI(user_prompt, relevance_check_prompt)

    if relevance_check.lower() == "no":
        score = "0%"
        insights = f"The prompt is not related to the selected domain of {domain}."
        enhanced_prompt = f"Try asking something related to the domain of {domain}."
    else:
        scoring_prompt = f"On a scale from 0 to 100%, rate the efficiency of the following prompt in the context of {domain}, considering factors like clarity, relevance, and potential for generating useful responses:"
        score = gptOpenAI(user_prompt, scoring_prompt)

        insights_prompt = f"Analyze the following prompt within the domain of {domain}. Provide detailed insights about its clarity, specificity, relevance, and effectiveness:"
        insights = gptOpenAI(user_prompt, insights_prompt)

        enhancement_prompt = f"Based on the insights, generate a more efficient and refined version of the following prompt suitable for the {domain} domain:"
        enhanced_prompt = gptOpenAI(user_prompt, enhancement_prompt)
    
    return score, insights, enhanced_prompt

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        user_prompt = request.form.get("user_prompt")
        domain = request.form.get("domain")
        
        score, insights, enhanced_prompt = prompt_validator(user_prompt, domain)
        
        return render_template("index.html", score=score, insights=insights, enhanced_prompt=enhanced_prompt, user_prompt=user_prompt, domain=domain)

    return render_template("index.html", score=None, insights=None, enhanced_prompt=None)

if __name__ == "__main__":
    app.run(debug=True)
